<?php
require_once("admin_header.php"); 

?>


<table <?php echo $inner_table_param; ?>>
  <tr>
    <td>
<?php
	
require_once("../includes/error_message.php");

?>
Content goes here...
	</td>
  </tr>
</table>


<?php 

require_once("admin_footer.php"); 

?>
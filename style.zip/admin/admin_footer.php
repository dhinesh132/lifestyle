   <!--Footer Start from Here-->
    <div id="footer">
    <div class="content">
    <span class="floatright"></span>
    <strong>Copyright© 2017 <?php echo $GLOBALS['site_config']['company_name']; ?> . All Rights Reserved.</strong>.
     </div>
</div>  <!--Footer End  Here-->

 

</body></html>
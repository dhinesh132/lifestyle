<?php
	echo "This is an article page<br>";
	echo "article id:".$_GET["article_id"]; 
	echo "<br>";
	echo "article id:".$_GET["article_name"]; 
	echo "<br>";
	echo "article body: blah blah..."; 
?>

<?php 

require_once("header.php"); 

?>


<table <?php echo $inner_table_param; ?>>
  <tr>
    <td>Content of the page goes here...</td>
  </tr>
</table>


<?php 

require_once("footer.php"); 

?>